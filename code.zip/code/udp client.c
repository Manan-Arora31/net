#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
int main(void)
{
    int socketid = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (socketid < 0)
    {
        printf("error in socket\n");
        return 1;
    }
    struct sockaddr_in port_addr;
    port_addr.sin_family = AF_INET;
    port_addr.sin_port = htons(5001);
    port_addr.sin_addr.s_addr = inet_addr("192.168.0.161");
    if (bind(socketid, (struct sockadd_in *)&port_addr, sizeof(port_addr)) < 0)
    {
        printf("error in bind\n");
        return 1;
    }
    struct sockaddr_in servaddr;
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(5000);
    servaddr.sin_addr.s_addr = inet_addr("192.168.0.161");
    char *buffer;
    // scanf("%s", buffer);
    // int len = strlen(buffer);

    char msg[30] = "hello there!";
    gets(msg);
    int msgLen = sizeof(msg) / sizeof(char);
    int valsend = sendto(socketid, msg, msgLen, 0, (struct sockaddr_in *)&servaddr, sizeof(servaddr));
    close(socketid);
}