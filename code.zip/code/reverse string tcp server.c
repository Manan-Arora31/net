#include<stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
 #include <sys/types.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#define PORT 8080


void reverse(char *buff){
	int n  = strlen(buff);
	int i = 0;
	for(;i < n/2;i++){
		char ch = buff[i];
		buff[i] = buff[n - i - 1];
		buff[n - 1 - i] = ch;
	}


}

int main(int argc,char *argv[]){
	int port = atoi(argv[1]);
	struct sockaddr_in server,client;

	int sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if(sockfd < 0){
		printf("error in sockfd\n");
		exit(1);
	}
	
	memset(&server,0,sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = htonl(INADDR_ANY);

	int b = bind(sockfd,(struct sockaddr*)&server,sizeof(server));
	if(b < 0){
		printf("bind failed");
		exit(1);
	}
	

	int l = listen(sockfd,10);
	if(l < 0){
                printf("listen failed");
                exit(1);
        }
	
	printf("Server is listening\n");

	int len = sizeof(client);
	int fd = accept(sockfd,(struct sockaddr*)&client,&len);
	
	printf("Client connected at port :%d\n",port);

	if(fd	 < 0){
                printf("accept failed");
                exit(1);
        }

	while(1){
			
		 char buff[100];
			
		int size = read(fd,buff,sizeof(buff));
		buff[size] = '\0';
		
		printf("read from client :%s\n",buff);
		
		reverse(buff);

		int sent = write(fd,buff,sizeof(buff));
		printf("Sending to client: %s\n",buff);

	}
	printf("Connection closing by the client\n");
	close(sockfd);
	return 0;
}


