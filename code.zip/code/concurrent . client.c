#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/types.h>
#include <sys/socket.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#define port 4000
#include<string.h>

int main(){
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in server;
	

	memset(&server,'\0',sizeof(server));
	server.sin_family = AF_INET;
        server.sin_addr.s_addr = inet_addr("127.0.0.1");
        server.sin_port = htons(port);


	connect(sockfd,(struct sockaddr *)&server,sizeof(server));
		
	printf("Connected to server at %s,%d\n",inet_ntoa(server.sin_addr),ntohs(server.sin_port));

	while(1){
		char buff[100];
		printf("Enter the string to send to server: ");
		fgets(buff,sizeof(buff),stdin);

		write(sockfd,buff,sizeof(buff));


		if(strncmp(buff,"exit",4) == 0){
			printf("Dsconnected to server at %s,%d\n",inet_ntoa(server.sin_addr),ntohs(server.sin_port));
			break;
		}

		int size = read(sockfd,buff,sizeof(buff));

		buff[size] = '\0';

		printf("recieved from server: %s\n",buff);
	}

	close(sockfd);
}
