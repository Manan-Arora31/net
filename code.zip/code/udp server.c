#include <stdio.h>
#include <strings.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
int main(void)
{
    int socketid = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (socketid < 0)
    {
        printf("error in socket\n");
        return 1;
    }
    struct sockaddr_in port_addr;
    port_addr.sin_family = AF_INET;
    port_addr.sin_port = htons(5000);
    port_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(socketid, (struct sockadd_in *)&port_addr, sizeof(port_addr)) < 0)
    {
        printf("error in bind\n");
        return 1;
    }
    struct sockaddr_in clientaddr;
    int len = sizeof(clientaddr);
    char buffer[1024];
    int readval = recvfrom(socketid, buffer, 1023, 0, (struct sockaddr_in *)&clientaddr, &len);
    printf("%s", buffer);
    close(socketid);
}