#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/types.h>
#include <sys/socket.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#define port 4000
#include<string.h>

int main(){

        int sockfd = socket(AF_INET, SOCK_DGRAM, 0);

        struct sockaddr_in server;
	

	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

	char buff[100];

	printf("Enter string to send");
	fgets(buff,sizeof(buff),stdin);

	int len = sizeof(server);

	sendto(sockfd,(const char*)buff,sizeof(buff),MSG_CONFIRM,(struct sockaddr *)&server,len);
	int size = recvfrom(sockfd,(char *)buff,sizeof(buff),MSG_WAITALL,(struct sockaddr *)&server,&len);
       buff[size] = '\0';

       printf("From server:%s\n",buff);
}
