#include<stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
 #include <sys/types.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<arpa/inet.h>
#define PORT 8080

int main(int argc,char* argv[]){
	
	int port = atoi(argv[1]);

	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in server;

	memset(&server,0,sizeof(server));

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr("127.0.0.1");
	server.sin_port = htons(port);
	

	connect(sockfd,(struct sockaddr *)&server,sizeof(server));
	
	printf("CLient to server at the port : %d\n",port);

	while(1){
		char buff[100];

		printf("Enter a string to send to server: ");
		fgets(buff,sizeof(buff),stdin);
		write(sockfd,buff,sizeof(buff));

		printf("sending to server: %s\n",buff);

		int size = read(sockfd,buff,sizeof(buff));
			
		buff[size] = '\0';

		printf("recieved from server: %s\n",buff);
	}

}
