#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/types.h>       
#include <sys/socket.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#define port 4000
#include<string.h>


int main(){
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in server,client;

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr("127.0.0.1");
	server.sin_port = htons(port);

	bind(sockfd,(struct sockaddr *)&server,sizeof(server));

	listen(sockfd,5);
	printf("Server is listening at port: %d\n",port);
	
	int len = sizeof(client);
	while(1){
		int fd = accept(sockfd,(struct sockaddr *)&client, &len);
		if(fd < 0){
			exit(1);
		}		
	
		printf("Server connected to %s , %d\n",inet_ntoa(client.sin_addr),ntohs(client.sin_port));
		if(fork() == 0){
			close(sockfd);

			while(1){
				char buff[100];
				int size = read(fd,buff,sizeof(buff));
				
				printf("From client: %s\n",buff);
				buff[size] = '\0';

				if(strncmp(buff,"exit",4) == 0){
					printf("Server disconnected from client: %s , %d\n",inet_ntoa(client.sin_addr),ntohs(client.sin_port));
					break;
				}
				
				write(fd,buff,sizeof(buff));

				printf("Sent from server to client: %s\n",buff);

			}
		}
	}	
	close(sockfd);

}


