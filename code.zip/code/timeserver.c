#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>

#define PORT 12345
#define BUFFER_SIZE 1024

int main() {
    struct sockaddr_in serverAddr, clientAddr;
    int sockfd, clientSockfd, addrLen, n;
    char buffer[BUFFER_SIZE];

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Error in socket creation");
        exit(EXIT_FAILURE);
    }

    memset(&serverAddr, 0, sizeof(serverAddr));
    memset(&clientAddr, 0, sizeof(clientAddr));

    // Configure server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    // Bind socket to the address and port
    if (bind(sockfd, (const struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error in binding");
        exit(EXIT_FAILURE);
    }

    printf("Server is listening for requests...\n");

    addrLen = sizeof(clientAddr);

    while (1) {
        // Receive request from client
        n = recvfrom(sockfd, (char *)buffer, BUFFER_SIZE, MSG_WAITALL, (struct sockaddr *)&clientAddr, &addrLen);
        buffer[n] = '\0';

        printf("Received request from client: %s\n", buffer);

        // Get current time
        time_t currentTime;
        struct tm *localTime;
        time(&currentTime);
        localTime = localtime(&currentTime);

        // Send time of day information to client
        char *timeStr = asctime(localTime);
        sendto(sockfd, (const char *)timeStr, strlen(timeStr), 0, (const struct sockaddr *)&clientAddr, addrLen);
        printf("Sent time of day information to client\n");
    }

    close(sockfd);
    return 0;
}

