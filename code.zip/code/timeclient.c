#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <server_ip_address> <server_port_number>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in serverAddr;
    int sockfd, n;
    char buffer[BUFFER_SIZE];

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Error in socket creation");
        exit(EXIT_FAILURE);
    }

    memset(&serverAddr, 0, sizeof(serverAddr));

    // Configure server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(argv[1]);
    serverAddr.sin_port = htons(atoi(argv[2]));

    // Send request to server
    sendto(sockfd, "Requesting Time", strlen("Requesting Time"), 0, (const struct sockaddr *)&serverAddr, sizeof(serverAddr));

    // Receive time of day information from server
    n = recvfrom(sockfd, (char *)buffer, BUFFER_SIZE, MSG_WAITALL, NULL, NULL);
    buffer[n] = '\0';

    printf("Received time of day information from server: %s\n", buffer);

    close(sockfd);
    return 0;
}

