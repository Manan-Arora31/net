#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/types.h>
#include <sys/socket.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#define port 4000
#include<string.h>

void reverse(char *buff){
	int n = strlen(buff);

	int i = 0;

	for(;i < n / 2;i++){
		char ch = buff[i];
		buff[i] = buff[n - i - 1];
		buff[n - i - 1] = ch;
	}
}

int main(){

	int sockfd = socket(AF_INET, SOCK_DGRAM, 0);

	struct sockaddr_in server,client;

	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");

	bind(sockfd,(struct sockaddr *)&server,sizeof(server));
	

	char buff[100];
	int len = sizeof(client);
	int size = recvfrom(sockfd,(char *)buff,sizeof(buff),MSG_WAITALL,(struct sockaddr *)&client,&len);
       buff[size] = '\0';
	
	int n = strlen(buff);
	
	printf("from client: %s , THe size is : %d\n",buff,n);       
		
	reverse(buff);
	
	sendto(sockfd,(const char *)buff,sizeof(buff),MSG_CONFIRM,(struct sockaddr *)&client,len);

	printf("to client:%s\n",buff);
}
